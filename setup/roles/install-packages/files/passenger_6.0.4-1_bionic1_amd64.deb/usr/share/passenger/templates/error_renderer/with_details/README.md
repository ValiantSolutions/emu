# Editing

Modifications to the `with_details` error renderer will become active after you do a compilation with webpack:

	passenger/resources/templates/error_renderer/with_details> ../../../../node_modules/webpack/bin/webpack.js

N.B. webpack should be installed:

	passenger> npm i